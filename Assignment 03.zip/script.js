"use strict";

const divtwo = document.querySelector(".div2");
const divthree = document.querySelector(".div3");
const submit = document.querySelector(".submit");

const regex =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

divthree.classList.remove("hidden");
submit.addEventListener("click", function () {
  const mail = document.querySelector(".email").value;
  console.log(mail);
  if (mail === regex) {
    divthree.classList.add("hidden");
    divtwo.classList.remove("hidden");
  }
});

const viewless1 = document.querySelector(".viewless1");
const viewless2 = document.querySelector(".viewless2");
const viewless3 = document.querySelector(".viewless3");
const viewless4 = document.querySelector(".viewless4");
const viewless5 = document.querySelector(".viewless5");
const viewless6 = document.querySelector(".viewless6");

const view1 = document.querySelector(".view1");
const kinhnghiem = document.querySelector(".kinhnghiem");

const view2 = document.querySelector(".view2");
const hocvan = document.querySelector(".hocvan");

const view3 = document.querySelector(".view3");
const hoatdong = document.querySelector(".hoatdong");

const view4 = document.querySelector(".view4");
const sothich = document.querySelector(".sothich");

const view5 = document.querySelector(".view5");
const ngonngu = document.querySelector(".ngonngu");

const view6 = document.querySelector(".view6");
const kinang = document.querySelector(".kinang");

view1.addEventListener("click", function () {
  kinhnghiem.classList.remove("hidden");
  viewless1.classList.remove("hidden");
  viewless1.addEventListener("click", function () {
    kinhnghiem.classList.add("hidden");
    viewless1.classList.add("hidden");
  });
});

view2.addEventListener("click", function () {
  hocvan.classList.remove("hidden");
  viewless2.classList.remove("hidden");
  viewless2.addEventListener("click", function () {
    hocvan.classList.add("hidden");
    viewless2.classList.add("hidden");
  });
});

view3.addEventListener("click", function () {
  hoatdong.classList.remove("hidden");
  viewless3.classList.remove("hidden");
  viewless3.addEventListener("click", function () {
    hoatdong.classList.add("hidden");
    viewless3.classList.add("hidden");
  });
});

view4.addEventListener("click", function () {
  sothich.classList.remove("hidden");
  viewless4.classList.remove("hidden");
  viewless4.addEventListener("click", function () {
    sothich.classList.add("hidden");
    viewless4.classList.add("hidden");
  });
});

view5.addEventListener("click", function () {
  ngonngu.classList.remove("hidden");
  viewless5.classList.remove("hidden");
  viewless5.addEventListener("click", function () {
    ngonngu.classList.add("hidden");
    viewless5.classList.add("hidden");
  });
});

view6.addEventListener("click", function () {
  kinang.classList.remove("hidden");
  viewless6.classList.remove("hidden");
  viewless6.addEventListener("click", function () {
    kinang.classList.add("hidden");
    viewless6.classList.add("hidden");
  });
});
